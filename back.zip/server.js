const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());

var apiKey = 'e23315c539fdb6cb5a72ebfb1c29edc6';
app.get('/weather/:latitude/:longitude', async (req, res) => {
  try {
    const { latitude, longitude } = req.params;
  
    // Get the current date
    const currentDate = new Date();

    // Calculate the date for one week from now
    const oneWeekLater = new Date();
    oneWeekLater.setDate(currentDate.getDate() + 7);

    // Convert dates to Unix timestamps
    const currentTimestamp = Math.round(currentDate.getTime() / 1000);
    const oneWeekLaterTimestamp = Math.round(oneWeekLater.getTime() / 1000);

    // Fetch weather data for the next 7 days
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/forecast?lat=${latitude}&lon=${longitude}&exclude=current,minutely,hourly&start=${currentTimestamp}&end=${oneWeekLaterTimestamp}&appid=${apiKey}`);
    console.log(response.data);
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
