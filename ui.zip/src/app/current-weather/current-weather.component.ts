import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../weather.service';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-current-weather',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './current-weather.component.html',
  styleUrl: './current-weather.component.css'
})
export class CurrentWeatherComponent  implements OnInit  {
  title = 'WeatherApp';
  weather: any;
  foundItem: any;
  constructor(private weatherService: WeatherService,private route: ActivatedRoute){
    
  }
  ngOnInit(): void {
    this.weatherService.getWeatherData().subscribe(
      (result: any) =>{
        this.weather = result;
        let idToFind = this.route.snapshot.paramMap.get('id');
        this.foundItem = this.weather.list.find((Product: any) => Product.dt == idToFind);

        console.log(this.weather);
        console.log(this.foundItem);
      }
    )
  }
}
