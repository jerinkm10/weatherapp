import { RouterModule, Routes } from '@angular/router';
import { CurrentWeatherComponent } from './current-weather/current-weather.component';
import { ForecastWeatherComponent } from './forecast-weather/forecast-weather.component';
export const routes: Routes = [
    { path: '', component: ForecastWeatherComponent },
    { path: 'current/:id', component: CurrentWeatherComponent },
];
