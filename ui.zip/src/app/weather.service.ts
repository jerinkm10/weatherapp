import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
})
export class WeatherService {
//     lat :any;
//    lng :any;

//   public ngOnInit(): void {
//     this.getLocation();
//   }

//   getLocation() {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//         if (position) {
//           console.log("Latitude: " + position.coords.latitude +
//             "Longitude: " + position.coords.longitude);
//           this.lat = position.coords.latitude;
//           this.lng = position.coords.longitude;
//           console.log(this.lat);
//           console.log(this.lat);
//           this.getWeatherData(this.lat,this.lng);
//         }
//       },
//         (error) => console.log(error));
//     } else {
//       alert("Geolocation is not supported by this browser.");
//     }
//   }
    private apiUrl = 'http://localhost:3000/weather/10.530345/76.214729';

    constructor(private http: HttpClient) {}

    getWeatherData(): Observable<any> {
        return this.http.get(this.apiUrl);
    }
}
