import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../weather.service';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-forecast-weather',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './forecast-weather.component.html',
  styleUrl: './forecast-weather.component.css'
})
export class ForecastWeatherComponent  implements OnInit  {
  title = 'WeatherApp';
  weather: any
  constructor(private weatherService: WeatherService,private route: ActivatedRoute){
    
  }
  ngOnInit(): void {
    this.weatherService.getWeatherData().subscribe(
      (result: any) =>{
        this.weather = result;
        console.log();
      }
    )
  }

}
